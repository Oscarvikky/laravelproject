<template>
    <main class="px-[20px]">
        <h1>No Deposit page</h1>
    </main>
</template>
