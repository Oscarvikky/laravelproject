<template>
    <div class="container-fluid bg-[#2d2d2d]">
        <div class="">
            <p class="text-center text-white cadtext mb-10">
                Experience the future of trading and <br />
                education with AgapeTrades
            </p>
        </div>

        <div class="flex justify-evenly m-auto crd p-5">
            <div class="card col-4 p-10 cardy relative" style="width: 18rem">
                <img
                    src="/images/agape4.png"
                    class="card-img-top w-[166px] h-[166px] mx-auto"
                    alt="..."
                />

                <div class="card-body">
                    <h5 class="card-title text-center my-6">
                        Decentralized <br />
                        Trading Platform
                    </h5>
                    <div>
                        <p class="card-text text-center my-6 text-sm">
                            All you need to do at AgapeTrades <br />
                            is to subscribe to our software <br />
                            which will be used to connect your <br />
                            account with your broker or <br />
                            exchange for trading.
                        </p>

                        <img
                            src="/images/agape4.png"
                            class="card-img-top cardimgg absolute bottom-4"
                            alt="..."
                        />
                    </div>
                </div>
            </div>
            <div class="card col-4 tp-10 cardy relative" style="width: 18rem">
                <img
                    src="/images/agape5.png"
                    class="card-img-top w-[166px] h-[166px] mx-auto"
                    alt="..."
                />

                <div class="card-body">
                    <h5 class="card-title text-center my-6">
                        AgapeTrades <br />
                        Academy
                    </h5>
                    <p class="card-text text-center my-6 text-sm">
                        We offer a great service through <br />
                        our Academy, to people who are <br />
                        interested in earning consistent <br />
                        income on daily, weekly or monthly <br />
                        basis. We share part of our profit <br />
                        with our students according to
                        <br />
                        their stage and level.

                        <img
                            src="/images/agape5.png"
                            class="card-img-top cardimggg absolute bottom-0 right-5"
                            alt="..."
                        />
                    </p>
                </div>
            </div>
            <div class="card col-4 p-10 cardy relative" style="width: 18rem">
                <img
                    src="/images/agape6.png"
                    class="card-img-top cardimg mx-auto z-50"
                    alt="..."
                />
                <img
                    src="/images/agape6.png"
                    class="card-img-top cardimgggg absolute top-0 left-1"
                    alt="..."
                />
                <div class="card-body">
                    <h5 class="card-title text-center my-6">
                        Maximize Your <br />
                        Earnings
                    </h5>
                    <p class="card-text text-center my-6 text-sm">
                        Benefit from an unparalleled <br />
                        referral system. Earn bonuses and <br />
                        share in 11% of your referrals'<br />
                        earnings for three months, <br />
                        amplifying your potential profits.
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
.crd {
    width: 90%;
}
.cardimgg {
    width: 166px;
    height: 166px;
    margin: auto;
    filter: blur(38px);
    z-index: -60px !important;
}
.cardimggg {
    width: 200px;
    height: 186px;
    margin: auto;
    filter: blur(15px);
    z-index: -60px;
}
.cardimgggg {
    width: 250px;
    height: 266px;
    margin: auto;
    filter: blur(30px);
    z-index: -60px;
}
.cardy {
    width: 330px !important;
    font-family: Rubik;
    font-size: 18px;
    font-weight: 500;
    background-color: #262626;
    color: white;
}
.cadtext {
    font-size: 45px;
    font-weight: 400;
    font-family: DM Mono;
    word-spacing: 10px;
    z-index: 20px;
}
</style>
