<template>
  <div class="container-fluid">
    <div class="text-center twtext-white twmy-20">
      <h5>
        How Does <br />
        AgapeTrade Works?
      </h5>
      <p>A simple guide on how to use our software.</p>
    </div>
    <div class="d-flex twjustify-evenly m-auto many">
      <div class="col-6">
        <img class="imgf" src="/image/agape7.png" alt="" />
      </div>

      <div class="col-6 gty twp-14">
        <div class="d-flex twjustify-evenly">
          <img class="fstimg" src="/image/agape10.png" alt="" />
          <p class="twtext-white">
            <span>Create Accout</span> <br />
            Subscribe to our advanced trading <br />
            software, designed to seamlessly <br />
            integrate with your chosen broker <br />
            or exchange.
          </p>
        </div>
        <div class="d-flex twjustify-evenly">
          <img class="fstimg" src="/image/agape9.png" alt="" />
          <p class="twtext-white">
            <span>Fund Wallet</span> <br />
            Fund your wallet to get started <br />
            with our academy program or hire a <br />
            trading software.
          </p>
        </div>
        <div class="d-flex twjustify-evenly">
          <img class="fstimg" src="/image/agape10.png" alt="" />
          <p class="twtext-white">
            <span>Subscribe to AgapeTrades Software</span> <br />
            Subscribe to our advanced trading <br />
            software, designed to seamlessly <br />
            integrate with your chosen broker <br />
            or exchange.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.fstimg {
  width: 56px;
  height: 56px;
}
.many {
  width: 70%;
}
.imgf {
  width: 450px;
  height: 450px;
}
.gty {
  width: 40%;
  padding: 70px;
}
span {
  font-weight: 500;
  /* font-family: Rubik; */
}
h5 {
  font-size: 30px;
  font-family: DM Mono;
  word-spacing: 10px;
}
p {
  font-size: 12px;
}
</style>
