<template>
  <div class="container twmy-20">
    <div class="row tww-9/12 m-auto">
      <div class="col-6">
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">Who we are ?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">How does the decentralized system work?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">How does the referral system work?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">How does the referral system work?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
      </div>

      <div class="col-6">
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">Who we are not?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">What is AgapeTrades Academy?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">Do I needtrading experience to join AgapeTrades?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
        <div class="bg-dark rounded twtext-white ty my-2">
          <p class="m-3">Can I earn money while learning at the Academy?</p>
          <img class="me-3" src="/image/agape11.png" alt="" />
        </div>
      </div>
    </div>
  </div>
  <hr class="" />
</template>

<style scoped>
.ty {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
p {
  font-size: 16px;
  font-family: DM Mono;
}
hr {
  color: #ffffff3d;
  font-size: 10px;
  font-weight: 800;
  margin: auto;
  width: 50%;
  border: 2px solid #ffffff3d;
  margin-top: 200px;
  margin-bottom: 80px;
}
img {
  width: 40px;
  height: 40px;
}
</style>
