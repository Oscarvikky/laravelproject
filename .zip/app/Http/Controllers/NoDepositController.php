<?php

namespace App\Http\Controllers;

use App\Models\No_Deposit;
// use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NoDepositController extends Controller
{
    //
    public function subscribePackage(Request $request){
        $user = Auth::user();
        $package = $request->input('name');
        $amount = $request->input('price');
        $active = $request->input('active');

        if($user->$active){
            return response()->json("you already subscribe for this package", 409);
        }
       if($user->wallet < $amount){
        return response()->json("insufficent balance", 406);
       }
      $user->$active = true;
      $user->wallet -= $amount;
      $expires = Carbon::now()->addDays(30*9);
      $user->save();


      No_Deposit::create([
        "user_id" => $user->id,
        "name" => $user->name,
        "amount" => $amount,
        "acc_type" =>$package,
        "deposit_count"=> 0,
        "last_recieved" => Carbon::now(),
        "subscribtion_expires" =>$expires
      ]);
      return response()->json("you have successfully subscribe for this package", 200);



    }
}
